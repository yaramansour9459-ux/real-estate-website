import React, { createContext, useContext, useState, useEffect } from 'react';
import { Property, Language, Theme } from '../types';

// Define the shape of our content
interface AppContent {
  [key: string]: string;
}

// Translations Dictionary
const translations = {
  ar: {
    "nav.home": "الرئيسية",
    "nav.services": "خدماتنا",
    "nav.featured": "عقارات مميزة",
    "nav.contact": "تواصل معنا",
    "nav.admin": "دخول المشرف",
    "nav.adminMode": "وضع المشرف",
    "nav.logout": "خروج",
    "hero.badge": "نصنع مستقبلك العقاري",
    "hero.contact": "تواصل معنا",
    "prop.available": "متاح",
    "prop.viewAll": "عرض الكل",
    "prop.add": "إضافة عقار",
    "prop.sar": "ر.س",
    "prop.moreComing": "المزيد قادم قريباً",
    "prop.moreDesc": "نقوم بإضافة عقارات جديدة يومياً. تواصل معنا للحصول على عروض حصرية.",
    "footer.rights": "جميع الحقوق محفوظة.",
    "footer.quickLinks": "روابط سريعة",
    "footer.types": "أنواع العقارات",
    "footer.contact": "معلومات التواصل",
    "modal.loginTitle": "تسجيل دخول المشرف",
    "modal.email": "البريد الإلكتروني",
    "modal.note": "الصلاحية محصورة فقط للبريد الإلكتروني:",
    "modal.loginBtn": "تسجيل الدخول",
    "addProp.title": "إضافة عقار جديد",
    "addProp.name": "اسم العقار",
    "addProp.price": "السعر (ر.س)",
    "addProp.location": "الموقع",
    "addProp.area": "المساحة (م²)",
    "addProp.rooms": "الغرف",
    "addProp.baths": "دورات المياه",
    "addProp.video": "رابط الفيديو (اختياري)",
    "addProp.description": "تفاصيل العقار",
    "addProp.images": "صور العقار (رابط URL)",
    "addProp.save": "حفظ العقار",
    "addProp.cancel": "إلغاء",
    "addProp.cover": "الغلاف",
    "addProp.setCover": "تعيين كغلاف",
    "settings.theme": "المظهر",
    "settings.lang": "اللغة",
    "settings.dark": "داكن",
    "settings.light": "فاتح",
  },
  en: {
    "nav.home": "Home",
    "nav.services": "Services",
    "nav.featured": "Featured",
    "nav.contact": "Contact Us",
    "nav.admin": "Admin Login",
    "nav.adminMode": "Admin Mode",
    "nav.logout": "Logout",
    "hero.badge": "Building Your Real Estate Future",
    "hero.contact": "Contact Us",
    "prop.available": "Available",
    "prop.viewAll": "View All",
    "prop.add": "Add Property",
    "prop.sar": "SAR",
    "prop.moreComing": "More Coming Soon",
    "prop.moreDesc": "We are adding new properties daily. Contact us for exclusive offers.",
    "footer.rights": "All rights reserved.",
    "footer.quickLinks": "Quick Links",
    "footer.types": "Property Types",
    "footer.contact": "Contact Info",
    "modal.loginTitle": "Admin Login",
    "modal.email": "Email Address",
    "modal.note": "Access restricted to:",
    "modal.loginBtn": "Login",
    "addProp.title": "Add New Property",
    "addProp.name": "Property Name",
    "addProp.price": "Price (SAR)",
    "addProp.location": "Location",
    "addProp.area": "Area (m²)",
    "addProp.rooms": "Bedrooms",
    "addProp.baths": "Bathrooms",
    "addProp.video": "Video URL (Optional)",
    "addProp.description": "Property Details",
    "addProp.images": "Images (URL)",
    "addProp.save": "Save Property",
    "addProp.cancel": "Cancel",
    "addProp.cover": "Cover",
    "addProp.setCover": "Set Cover",
    "settings.theme": "Theme",
    "settings.lang": "Language",
    "settings.dark": "Dark",
    "settings.light": "Light",
  }
};

interface AppContextType {
  isAdmin: boolean;
  login: (email: string) => boolean;
  logout: () => void;
  content: AppContent;
  updateContent: (key: string, value: string) => void;
  isEditMode: boolean;
  toggleEditMode: () => void;
  properties: Property[];
  addProperty: (property: Property) => void;
  deleteProperty: (id: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  toggleTheme: () => void;
  t: (key: keyof typeof translations['ar']) => string;
}

const defaultContent: AppContent = {
  "hero.title": "عقارات راقية بأسعار مميزة",
  "hero.subtitle": "نوفر لك أفضل العروض العقارية في منطقتك.",
  "hero.cta": "استعرض العقارات",
  "contact.phone": "053 498 0811",
  "contact.hours": "الأحد - الخميس: 9 ص - 10 م",
  "services.title": "خدماتنا المتميزة",
  "services.desc": "نقدم مجموعة متكاملة من الخدمات العقارية لتلبية جميع احتياجاتك",
  "about.title": "لماذا تختار نوفا؟",
  "about.desc": "نحن لا نبيع العقارات فحسب، بل نبني علاقات دائمة قائمة على الثقة والشفافية.",
};

// Initial sample properties
const defaultProperties: Property[] = [
  {
    id: '1',
    title: 'قصر الياسمين الحديث',
    price: 4500000,
    location: 'الرياض، حي الملقا',
    bedrooms: 5,
    bathrooms: 6,
    area: 450,
    coverImage: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80",
    images: [
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80", 
      "https://images.unsplash.com/photo-1594916894389-9800d98f79d0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80", 
      "https://images.unsplash.com/photo-1620626012053-1c1abdb27923?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80", 
      "https://images.unsplash.com/photo-1560185007-cde436f6a4d0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80", 
      "https://images.unsplash.com/photo-1585128719715-46776b56a0d1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1600&q=80"
    ],
    description: "قصر فاخر يتميز بتصميم عصري وتشطيبات راقية. يحتوي على مسبح خاص وحديقة واسعة وصالات استقبال فسيحة."
  }
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false);
  const [content, setContent] = useState<AppContent>(defaultContent);
  const [properties, setProperties] = useState<Property[]>(defaultProperties);
  const [language, setLanguage] = useState<Language>('ar');
  const [theme, setTheme] = useState<Theme>('light');

  // Load state from localStorage on mount
  useEffect(() => {
    const savedAdmin = localStorage.getItem('nova_isAdmin');
    if (savedAdmin === 'true') {
      setIsAdmin(true);
      setIsEditMode(true);
    }

    const savedContent = localStorage.getItem('nova_content');
    if (savedContent) {
      setContent({ ...defaultContent, ...JSON.parse(savedContent) });
    }

    const savedProperties = localStorage.getItem('nova_properties');
    if (savedProperties) {
      setProperties(JSON.parse(savedProperties));
    }

    const savedLang = localStorage.getItem('nova_lang') as Language;
    if (savedLang) setLanguage(savedLang);

    const savedTheme = localStorage.getItem('nova_theme') as Theme;
    if (savedTheme) setTheme(savedTheme);
  }, []);

  // Update DOM when Language changes
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('nova_lang', language);
  }, [language]);

  // Update DOM when Theme changes
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('nova_theme', theme);
  }, [theme]);


  const login = (email: string) => {
    // Strictly check for the specific email
    if (email.toLowerCase() === 'yaramansour9459@gmail.com') {
      setIsAdmin(true);
      setIsEditMode(true);
      localStorage.setItem('nova_isAdmin', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAdmin(false);
    setIsEditMode(false);
    localStorage.removeItem('nova_isAdmin');
  };

  const toggleEditMode = () => {
    if (isAdmin) setIsEditMode(!isEditMode);
  };

  const updateContent = (key: string, value: string) => {
    const newContent = { ...content, [key]: value };
    setContent(newContent);
    localStorage.setItem('nova_content', JSON.stringify(newContent));
  };

  const addProperty = (property: Property) => {
    const updatedProperties = [property, ...properties];
    setProperties(updatedProperties);
    localStorage.setItem('nova_properties', JSON.stringify(updatedProperties));
  };

  const deleteProperty = (id: string) => {
    const updatedProperties = properties.filter(p => p.id !== id);
    setProperties(updatedProperties);
    localStorage.setItem('nova_properties', JSON.stringify(updatedProperties));
  };

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const t = (key: keyof typeof translations['ar']) => {
    return translations[language][key] || key;
  };

  return (
    <AppContext.Provider value={{ 
      isAdmin, 
      login, 
      logout, 
      content, 
      updateContent, 
      isEditMode, 
      toggleEditMode,
      properties,
      addProperty,
      deleteProperty,
      language,
      setLanguage,
      theme,
      toggleTheme,
      t
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
};
