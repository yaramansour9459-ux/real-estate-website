import React from 'react';

export type Language = 'ar' | 'en';
export type Theme = 'light' | 'dark';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  isError?: boolean;
}

export interface ServiceItem {
  title: string;
  desc: string;
  icon: React.ReactNode;
}

export interface Property {
  id: string;
  title: string;
  price: number;
  location: string;
  bedrooms: number;
  bathrooms: number;
  area: number; // in square meters
  images: string[];
  coverImage: string;
  videoUrl?: string;
  description?: string;
}
