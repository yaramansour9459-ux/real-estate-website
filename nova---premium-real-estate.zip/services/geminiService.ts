import { GoogleGenAI, Chat } from "@google/genai";
import { ChatMessage } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// System instruction for the real estate assistant
const SYSTEM_INSTRUCTION = `
أنت مستشار عقاري ذكي ومحترف لمنصة "نوفا هوم العقارية".
موقعنا الرئيسي: الرياض، حي السويدي، مخرج 26.
فروعنا: حي طيبة، الرياض.
رقم التواصل: 0534980811
أوقات العمل: من الأحد إلى الخميس، من الساعة 9 صباحاً حتى 10 مساءً.

دورك هو مساعدة المستخدمين في العثور على عقارات، تقديم نصائح حول الاستثمار العقاري، وشرح اتجاهات السوق في المملكة العربية السعودية والشرق الأوسط.
تحدث باللغة العربية بأسلوب ودود ومهني.
اجعل إجاباتك مختصرة ومفيدة.
إذا سألك المستخدم عن عقارات محددة، اقترح عليه أنواع العقارات المتاحة (فلل، شقق، أراضي) واطلب منه تفاصيل أكثر.
`;

export const createChatSession = (): Chat => {
  return ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
    },
  });
};

export const sendMessageToGemini = async (chat: Chat, message: string): Promise<string> => {
  try {
    const response = await chat.sendMessage({ message });
    return response.text || "عذراً، لم أستطع فهم ذلك. هل يمكنك إعادة صياغة السؤال؟";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error("حدث خطأ في الاتصال بالمساعد الذكي.");
  }
};