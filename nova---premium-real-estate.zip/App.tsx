import React, { useState } from "react";
import { motion } from "framer-motion";
import { MapPin, Phone, Home, ArrowLeft, Menu, X, CheckCircle, Star, BedDouble, Bath, Clock, Lock, LogOut, Plus, Trash2, Maximize, PlayCircle, Globe, Moon, Sun, Settings } from "lucide-react";
import { Button, Card, CardContent } from "./components/ui/BaseComponents";
import { AIChatBot } from "./components/AIChatBot";
import { ImageCarousel } from "./components/ImageCarousel";
import { useAppContext } from "./contexts/AppContext";
import { EditableText } from "./components/ui/EditableText";
import { AdminLoginModal } from "./components/AdminLoginModal";
import { AddPropertyModal } from "./components/AddPropertyModal";
import { MediaLightbox } from "./components/MediaLightbox";

// Navbar Component with Settings
const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const { isAdmin, logout, t, language, setLanguage, theme, toggleTheme } = useAppContext();
  
  return (
    <>
      <nav className="fixed top-0 w-full z-40 bg-white/90 dark:bg-gray-900/90 backdrop-blur-md border-b border-gray-100 dark:border-gray-800 shadow-sm transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex-shrink-0 flex items-center gap-2">
              <Home className="w-9 h-9 text-primary-700 dark:text-primary-500" />
              <div className="flex flex-col">
                <span className="text-xl font-bold text-primary-700 dark:text-primary-500 leading-none">نوفا هوم</span>
                <span className="text-xs font-medium text-primary-500 dark:text-primary-400 mt-1">العقارية</span>
              </div>
            </div>
            
            <div className="hidden md:flex items-center gap-6">
              <a href="#" className="text-gray-600 dark:text-gray-300 hover:text-primary-600 font-medium transition-colors">{t('nav.home')}</a>
              <a href="#featured" className="text-gray-600 dark:text-gray-300 hover:text-primary-600 font-medium transition-colors">{t('nav.featured')}</a>
              <a href="#services" className="text-gray-600 dark:text-gray-300 hover:text-primary-600 font-medium transition-colors">{t('nav.services')}</a>
              
              {/* Settings Dropdown Trigger */}
              <div className="relative">
                <button 
                  onClick={() => setShowSettings(!showSettings)}
                  className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 text-gray-600 dark:text-gray-300 transition-colors"
                >
                  <Settings size={20} />
                </button>
                
                {/* Settings Dropdown */}
                {showSettings && (
                  <div className="absolute top-full mt-2 left-0 w-48 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-100 dark:border-gray-700 overflow-hidden py-1 z-50">
                     <div className="px-4 py-2 text-xs font-bold text-gray-400 uppercase tracking-wider">{t('settings.lang')}</div>
                     <button 
                       onClick={() => { setLanguage('ar'); setShowSettings(false); }} 
                       className={`w-full text-right px-4 py-2 text-sm flex items-center justify-between ${language === 'ar' ? 'bg-primary-50 text-primary-700 dark:bg-primary-900/20 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'}`}
                     >
                       <span>العربية</span>
                       {language === 'ar' && <CheckCircle size={14} />}
                     </button>
                     <button 
                       onClick={() => { setLanguage('en'); setShowSettings(false); }} 
                       className={`w-full text-right px-4 py-2 text-sm flex items-center justify-between ${language === 'en' ? 'bg-primary-50 text-primary-700 dark:bg-primary-900/20 dark:text-primary-400' : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'}`}
                     >
                       <span>English</span>
                       {language === 'en' && <CheckCircle size={14} />}
                     </button>

                     <div className="border-t border-gray-100 dark:border-gray-700 my-1"></div>
                     <div className="px-4 py-2 text-xs font-bold text-gray-400 uppercase tracking-wider">{t('settings.theme')}</div>
                     
                     <button 
                       onClick={() => { toggleTheme(); }} 
                       className="w-full text-right px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center gap-2"
                     >
                        {theme === 'light' ? <Moon size={16} /> : <Sun size={16} />}
                        {theme === 'light' ? t('settings.dark') : t('settings.light')}
                     </button>
                  </div>
                )}
              </div>

              {isAdmin ? (
                <div className="flex items-center gap-2">
                   <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded-full font-bold border border-green-200 whitespace-nowrap">{t('nav.adminMode')}</span>
                   <Button size="sm" variant="outline" onClick={logout} className="text-red-600 border-red-200 hover:bg-red-50">
                     <LogOut size={16} className={language === 'ar' ? 'ml-2' : 'mr-2'} /> {t('nav.logout')}
                   </Button>
                </div>
              ) : (
                <Button size="sm" onClick={() => setShowLogin(true)} variant="ghost" className="text-gray-500 dark:text-gray-400 hover:text-primary-600 dark:hover:text-primary-400 whitespace-nowrap">
                  <Lock size={16} className={language === 'ar' ? 'ml-1' : 'mr-1'} /> {t('nav.admin')}
                </Button>
              )}
              
              <Button size="sm" className="whitespace-nowrap">{t('nav.contact')}</Button>
            </div>

            <div className="md:hidden flex items-center gap-4">
              <button onClick={toggleTheme} className="text-gray-600 dark:text-gray-300">
                  {theme === 'light' ? <Moon size={24} /> : <Sun size={24} />}
              </button>
              <button onClick={() => setIsOpen(!isOpen)} className="text-gray-600 dark:text-gray-300">
                {isOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {isOpen && (
          <div className="md:hidden bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800">
            <div className="px-4 pt-2 pb-6 space-y-2">
              <a href="#" className="block px-3 py-2 text-base font-medium text-gray-700 dark:text-gray-200 hover:text-primary-600 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">{t('nav.home')}</a>
              <a href="#featured" className="block px-3 py-2 text-base font-medium text-gray-700 dark:text-gray-200 hover:text-primary-600 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">{t('nav.featured')}</a>
              <a href="#services" className="block px-3 py-2 text-base font-medium text-gray-700 dark:text-gray-200 hover:text-primary-600 hover:bg-gray-50 dark:hover:bg-gray-800 rounded-lg">{t('nav.services')}</a>
              
              <div className="flex gap-2 px-3 py-2">
                 <button onClick={() => setLanguage('ar')} className={`px-3 py-1 rounded text-sm ${language === 'ar' ? 'bg-primary-100 text-primary-700' : 'bg-gray-100 dark:bg-gray-800 dark:text-gray-300'}`}>عربي</button>
                 <button onClick={() => setLanguage('en')} className={`px-3 py-1 rounded text-sm ${language === 'en' ? 'bg-primary-100 text-primary-700' : 'bg-gray-100 dark:bg-gray-800 dark:text-gray-300'}`}>English</button>
              </div>

              <div className="pt-2 border-t border-gray-100 dark:border-gray-800 mt-2">
                 {isAdmin ? (
                   <Button className="w-full bg-red-50 text-red-600 hover:bg-red-100 mb-2" onClick={logout}>{t('nav.logout')}</Button>
                 ) : (
                   <Button className="w-full mb-2" variant="outline" onClick={() => { setShowLogin(true); setIsOpen(false); }}>{t('nav.admin')}</Button>
                 )}
                 <Button className="w-full">{t('nav.contact')}</Button>
              </div>
            </div>
          </div>
        )}
      </nav>

      <AdminLoginModal isOpen={showLogin} onClose={() => setShowLogin(false)} />
    </>
  );
};

export default function App() {
  const { isAdmin, properties, deleteProperty, t, language } = useAppContext();
  const [showAddModal, setShowAddModal] = useState(false);
  
  // Lightbox State
  const [lightbox, setLightbox] = useState<{
    isOpen: boolean;
    type: 'image' | 'video';
    mediaUrl?: string;
    images?: string[];
    index?: number;
  }>({
    isOpen: false,
    type: 'image',
    images: [],
    index: 0
  });

  const openImageLightbox = (images: string[], index: number) => {
    setLightbox({
      isOpen: true,
      type: 'image',
      images: images,
      index: index
    });
  };

  const openVideoLightbox = (url: string) => {
    setLightbox({
      isOpen: true,
      type: 'video',
      mediaUrl: url
    });
  };

  const closeLightbox = () => {
    setLightbox(prev => ({ ...prev, isOpen: false }));
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-100 font-sans selection:bg-primary-200 dark:selection:bg-primary-900 transition-colors duration-300">
      <Navbar />
      <AddPropertyModal isOpen={showAddModal} onClose={() => setShowAddModal(false)} />
      
      {/* Media Lightbox */}
      <MediaLightbox 
        isOpen={lightbox.isOpen} 
        onClose={closeLightbox}
        type={lightbox.type}
        mediaUrl={lightbox.mediaUrl}
        images={lightbox.images}
        initialIndex={lightbox.index}
      />
      
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image with Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80"
            alt="Luxury Home"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/30" />
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="max-w-4xl mx-auto"
          >
            <span className="inline-block py-1 px-3 rounded-full bg-primary-500/20 border border-primary-400/30 text-primary-50 backdrop-blur-sm text-sm font-medium mb-6">
              {t('hero.badge')}
            </span>
            <div className="text-5xl md:text-7xl font-bold mb-6 text-white leading-tight">
               <EditableText 
                 id="hero.title" 
                 defaultText="عقارات راقية بأسعار مميزة"
                 multiline
               />
            </div>
            <div className="text-xl text-gray-200 mb-10 max-w-2xl mx-auto leading-relaxed">
               <EditableText 
                 id="hero.subtitle" 
                 defaultText="نوفر لك أفضل العروض العقارية في منطقتك." 
               />
            </div>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Button size="lg" className="rounded-2xl px-8 py-6 text-lg shadow-xl shadow-primary-900/20">
                 <EditableText id="hero.cta" defaultText="استعرض العقارات" />
              </Button>
              <Button size="lg" variant="outline" className="rounded-2xl px-8 py-6 text-lg bg-white/10 text-white border-white/20 hover:bg-white/20 backdrop-blur-sm">
                {t('hero.contact')}
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Featured Properties Section (Moved Up) */}
      <section id="featured" className="py-24 bg-white dark:bg-gray-800 relative transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">أحدث العقارات</h2>
              <p className="text-gray-600 dark:text-gray-400">اكتشف أحدث الفرص العقارية المميزة</p>
            </div>
            <div className="flex gap-3">
              {isAdmin && (
                <Button onClick={() => setShowAddModal(true)} className="flex items-center gap-2">
                  <Plus size={20} /> {t('prop.add')}
                </Button>
              )}
              <Button variant="outline" className="hidden md:flex">{t('prop.viewAll')}</Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map((property) => (
              <motion.div
                key={property.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="col-span-1"
              >
                <Card className="group hover:shadow-2xl transition-all duration-300 border-gray-100 dark:border-gray-700 h-full flex flex-col relative overflow-visible">
                  {isAdmin && (
                    <button 
                      onClick={() => deleteProperty(property.id)}
                      className="absolute -top-3 -right-3 z-30 bg-red-500 text-white p-2 rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-600"
                    >
                      <Trash2 size={16} />
                    </button>
                  )}
                  
                  <div className="relative">
                    <ImageCarousel 
                      images={property.images} 
                      className="h-80" 
                      onImageClick={(idx) => openImageLightbox(property.images, idx)}
                    />
                    <div className="absolute top-4 right-4 bg-primary-600 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg z-20 pointer-events-none">
                      {t('prop.available')}
                    </div>
                    {property.videoUrl && (
                      <button 
                        onClick={() => openVideoLightbox(property.videoUrl!)}
                        className="absolute top-4 left-4 bg-black/50 text-white p-2 rounded-full hover:bg-black/70 backdrop-blur-sm z-20 transition-all hover:scale-110"
                      >
                        <PlayCircle size={24} />
                      </button>
                    )}
                    <div className="absolute bottom-4 left-4 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md px-2.5 py-1 rounded-lg text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1 shadow-sm z-20 pointer-events-none">
                      <Star size={12} className="text-yellow-500 fill-yellow-500" />
                      4.8
                    </div>
                  </div>
                  
                  <CardContent className="p-6 flex-1 flex flex-col">
                    <div className="text-primary-600 dark:text-primary-400 text-sm font-semibold mb-2">فيلا فاخرة</div>
                    <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white group-hover:text-primary-600 dark:group-hover:text-primary-400 transition-colors">{property.title}</h3>
                    
                    <p className="text-gray-500 dark:text-gray-400 text-sm mb-4 flex items-center gap-2">
                      <MapPin size={16} className="text-gray-400" />
                      {property.location}
                    </p>

                    {property.description && (
                        <p className="text-gray-600 dark:text-gray-300 text-sm mb-6 line-clamp-3">
                            {property.description}
                        </p>
                    )}
                    
                    <div className="mt-auto border-t border-gray-100 dark:border-gray-700 pt-5 flex items-center justify-between">
                      <div className="text-xl font-bold text-primary-700 dark:text-primary-400">{property.price.toLocaleString()} <span className="text-sm font-medium text-gray-500">{t('prop.sar')}</span></div>
                      <div className="flex gap-4 text-gray-500 dark:text-gray-400 text-sm">
                         <div className="flex items-center gap-1.5" title="المساحة">
                          <Maximize size={18} className="text-gray-400" />
                          <span className="font-bold text-gray-700 dark:text-gray-300">{property.area}م²</span>
                        </div>
                        <div className="w-px h-5 bg-gray-200 dark:bg-gray-700"></div>
                        <div className="flex items-center gap-1.5" title="عدد الغرف">
                          <BedDouble size={18} className="text-gray-400" />
                          <span className="font-bold text-gray-700 dark:text-gray-300">{property.bedrooms}</span>
                        </div>
                        <div className="w-px h-5 bg-gray-200 dark:bg-gray-700"></div>
                        <div className="flex items-center gap-1.5" title="عدد دورات المياه">
                          <Bath size={18} className="text-gray-400" />
                          <span className="font-bold text-gray-700 dark:text-gray-300">{property.bathrooms}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}

            {/* Placeholder for more properties */}
            <div className="col-span-1 md:col-span-1 lg:col-span-1 flex items-center justify-center bg-gray-50 dark:bg-gray-900 rounded-2xl border border-dashed border-gray-200 dark:border-gray-700 min-h-[400px]">
               <div className="text-center p-8">
                 <div className="w-14 h-14 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
                    <Home size={28} />
                 </div>
                 <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">{t('prop.moreComing')}</h3>
                 <p className="text-gray-500 dark:text-gray-400 text-sm max-w-xs mx-auto">{t('prop.moreDesc')}</p>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section (Moved Down) */}
      <section id="services" className="py-24 px-4 sm:px-8 max-w-7xl mx-auto bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
             <EditableText id="services.title" defaultText="خدماتنا المتميزة" />
          </h2>
          <div className="text-gray-600 dark:text-gray-400 text-lg">
             <EditableText id="services.desc" defaultText="نقدم مجموعة متكاملة من الخدمات العقارية لتلبية جميع احتياجاتك" multiline />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              icon: <Home className="w-10 h-10" />,
              title: "بيع وشراء العقارات",
              desc: "نربط البائعين بالمشترين من خلال شبكة واسعة وعروض حصرية تناسب جميع الميزانيات والتفضيلات."
            },
            {
              icon: <MapPin className="w-10 h-10" />,
              title: "إدارة الأملاك",
              desc: "خدمات إدارة شاملة تضمن صيانة عقارك، تحصيل الإيجارات، ومتابعة كافة الشؤون القانونية."
            },
            {
              icon: <Phone className="w-10 h-10" />,
              title: "استشارات عقارية",
              desc: "نقدّم لك توجيهات احترافية ودراسات جدوى لاتخاذ القرار الصحيح في استثماراتك العقارية."
            }
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="h-full hover:shadow-xl transition-shadow duration-300 border-none shadow-md">
                <CardContent className="flex flex-col items-center text-center p-8 h-full">
                  <div className="w-20 h-20 rounded-2xl bg-primary-50 dark:bg-gray-800 text-primary-600 dark:text-primary-400 flex items-center justify-center mb-6 shadow-inner">
                    {item.icon}
                  </div>
                  <h3 className="text-2xl font-bold mb-4 text-gray-900 dark:text-white">
                     <EditableText id={`service.${i}.title`} defaultText={item.title} />
                  </h3>
                  <div className="text-gray-600 dark:text-gray-400 leading-relaxed">
                     <EditableText id={`service.${i}.desc`} defaultText={item.desc} multiline />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-gray-900 dark:bg-black text-white relative overflow-hidden transition-colors duration-300">
         <div className="absolute top-0 right-0 w-1/3 h-full bg-primary-900/10 -skew-x-12 transform origin-top-right"></div>
         <div className="max-w-7xl mx-auto px-4 sm:px-8 relative z-10">
           <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
             <div>
               <h2 className="text-4xl font-bold mb-6">
                 <EditableText id="about.title" defaultText="لماذا تختار نوفا؟" />
               </h2>
               <div className="text-gray-400 text-lg mb-8">
                 <EditableText id="about.desc" defaultText="نحن لا نبيع العقارات فحسب، بل نبني علاقات دائمة قائمة على الثقة والشفافية." multiline />
               </div>
               <div className="space-y-6">
                 {[
                   "فريق من الخبراء العقاريين المعتمدين",
                   "تحليل سوق دقيق ومدعوم بالبيانات",
                   "إجراءات قانونية موثقة وآمنة 100%",
                   "خدمة عملاء متميزة على مدار الساعة"
                 ].map((text, idx) => (
                   <div key={idx} className="flex items-center gap-4">
                     <div className="w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center shrink-0">
                       <CheckCircle size={18} />
                     </div>
                     <span className="text-lg">
                       <EditableText id={`about.point.${idx}`} defaultText={text} />
                     </span>
                   </div>
                 ))}
               </div>
             </div>
             <div className="relative h-96 rounded-3xl overflow-hidden shadow-2xl border-4 border-gray-800">
               <img src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=1073&q=80" alt="Team" className="w-full h-full object-cover" />
               <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent opacity-80"></div>
               <div className="absolute bottom-6 right-6">
                 <div className="text-3xl font-bold text-white">+10</div>
                 <div className="text-gray-300">سنوات من الخبرة</div>
               </div>
             </div>
           </div>
         </div>
      </section>

      {/* Contact Section */}
      <section className="bg-white dark:bg-gray-900 py-24 px-4 sm:px-8 text-center transition-colors duration-300">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-4xl font-bold mb-6 text-gray-900 dark:text-white">جاهز لبدء رحلتك؟</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-10 text-xl">يسعدنا مساعدتك في إيجاد العقار المثالي لك ولعائلتك. فريقنا جاهز للإجابة على جميع استفساراتك.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" className="rounded-2xl px-12 py-6 text-lg shadow-lg shadow-primary-500/20">
              اتصل الآن
            </Button>
            <Button size="lg" variant="outline" className="rounded-2xl px-12 py-6 text-lg">
              تصفح الأسئلة الشائعة
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-50 dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800 pt-16 pb-8 transition-colors duration-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Home className="w-8 h-8 text-primary-700 dark:text-primary-500" />
                 <div className="flex flex-col">
                  <span className="text-2xl font-bold text-primary-700 dark:text-primary-500 leading-none">نوفا هوم</span>
                  <span className="text-sm font-medium text-primary-500 dark:text-primary-400 mt-1">العقارية</span>
                </div>
              </div>
              <p className="text-gray-500 dark:text-gray-400 leading-relaxed">
                منصتك العقارية الأولى في المملكة. نجمع بين الخبرة التقليدية والتقنية الحديثة لتقديم أفضل تجربة عقارية.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-4">{t('footer.quickLinks')}</h4>
              <ul className="space-y-2 text-gray-600 dark:text-gray-400">
                <li><a href="#" className="hover:text-primary-600 dark:hover:text-primary-400">{t('nav.home')}</a></li>
                <li><a href="#" className="hover:text-primary-600 dark:hover:text-primary-400">{t('nav.services')}</a></li>
                <li><a href="#" className="hover:text-primary-600 dark:hover:text-primary-400">{t('nav.contact')}</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-4">{t('footer.types')}</h4>
              <ul className="space-y-2 text-gray-600 dark:text-gray-400">
                <li><a href="#" className="hover:text-primary-600 dark:hover:text-primary-400">فلل للبيع</a></li>
                <li><a href="#" className="hover:text-primary-600 dark:hover:text-primary-400">شقق للإيجار</a></li>
                <li><a href="#" className="hover:text-primary-600 dark:hover:text-primary-400">أراضي تجارية</a></li>
                <li><a href="#" className="hover:text-primary-600 dark:hover:text-primary-400">مكاتب</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-gray-900 dark:text-white mb-4">{t('footer.contact')}</h4>
              <ul className="space-y-4 text-gray-600 dark:text-gray-400">
                <li className="flex items-center gap-2">
                  <Phone size={16} className="text-primary-600 dark:text-primary-400" /> 
                  <span dir="ltr">
                    <EditableText id="contact.phone" defaultText="053 498 0811" />
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Clock size={16} className="mt-1 shrink-0 text-primary-600 dark:text-primary-400" />
                  <div>
                    <span className="font-bold text-gray-900 dark:text-white block text-sm">أوقات العمل</span>
                    <span className="text-sm">
                      <EditableText id="contact.hours" defaultText="الأحد - الخميس: 9 ص - 10 م" />
                    </span>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <MapPin size={16} className="mt-1 shrink-0 text-primary-600 dark:text-primary-400" />
                  <div>
                    <span className="font-bold text-gray-900 dark:text-white block text-sm">المقر الرئيسي</span>
                    <span className="text-sm">
                      <EditableText id="contact.location1" defaultText="الرياض، السويدي، مخرج 26" />
                    </span>
                  </div>
                </li>
                <li className="flex items-start gap-2">
                  <MapPin size={16} className="mt-1 shrink-0 text-primary-600 dark:text-primary-400" />
                  <div>
                    <span className="font-bold text-gray-900 dark:text-white block text-sm">فروعنا</span>
                    <span className="text-sm">
                      <EditableText id="contact.location2" defaultText="الرياض، حي طيبة" />
                    </span>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-200 dark:border-gray-800 pt-8 text-center text-gray-400 text-sm">
            © {new Date().getFullYear()} نوفا هوم العقارية. {t('footer.rights')}
          </div>
        </div>
      </footer>

      {/* AI Chat Bot Overlay */}
      <AIChatBot />
    </div>
  );
}
