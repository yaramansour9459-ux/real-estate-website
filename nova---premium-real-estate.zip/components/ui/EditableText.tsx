import React, { useState, useEffect, useRef } from 'react';
import { Pencil } from 'lucide-react';
import { useAppContext } from '../../contexts/AppContext';

interface EditableTextProps {
  id: string; // The key in the content object
  defaultText: string;
  className?: string;
  multiline?: boolean;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span' | 'div';
}

export const EditableText: React.FC<EditableTextProps> = ({ 
  id, 
  defaultText, 
  className = "", 
  multiline = false,
  as: Component = 'span'
}) => {
  const { isEditMode, content, updateContent } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState('');
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  // Get current text from context or fallback to default
  const currentText = content[id] || defaultText;

  useEffect(() => {
    setTempValue(currentText);
  }, [currentText]);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isEditing]);

  const handleSave = () => {
    if (tempValue !== currentText) {
      updateContent(id, tempValue);
    }
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !multiline) {
      e.preventDefault();
      handleSave();
    }
    if (e.key === 'Escape') {
      setTempValue(currentText);
      setIsEditing(false);
    }
  };

  if (isEditMode && isEditing) {
    const inputClasses = `w-full bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 border-b-2 border-primary-500 outline-none p-1 shadow-lg z-50 relative ${className}`;
    
    return (
      <div className="relative inline-block w-full min-w-[100px]" onClick={(e) => e.stopPropagation()}>
        {multiline ? (
          <textarea
            ref={inputRef as React.RefObject<HTMLTextAreaElement>}
            value={tempValue}
            onChange={(e) => setTempValue(e.target.value)}
            onBlur={handleSave}
            onKeyDown={handleKeyDown}
            className={inputClasses}
            rows={4}
          />
        ) : (
          <input
            ref={inputRef as React.RefObject<HTMLInputElement>}
            type="text"
            value={tempValue}
            onChange={(e) => setTempValue(e.target.value)}
            onBlur={handleSave}
            onKeyDown={handleKeyDown}
            className={inputClasses}
          />
        )}
        <div className="absolute top-full left-0 right-0 text-[10px] text-primary-500 bg-white dark:bg-gray-800 px-1 shadow-sm rounded-b opacity-70">
          اضغط Enter للحفظ، Esc للإلغاء
        </div>
      </div>
    );
  }

  return (
    <div 
      className={`relative group inline-block ${isEditMode ? 'cursor-pointer hover:bg-primary-500/10 dark:hover:bg-primary-500/20 rounded-md transition-all -m-1 p-1 border border-transparent hover:border-dashed hover:border-primary-400' : ''}`}
      onClick={(e) => {
        if (isEditMode) {
          e.stopPropagation();
          setIsEditing(true);
        }
      }}
    >
      <Component className={className}>
        {currentText}
      </Component>
      {isEditMode && (
        <span className="absolute -top-2 -right-2 bg-white dark:bg-gray-700 text-primary-600 dark:text-primary-400 p-1 rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity z-10">
          <Pencil size={10} />
        </span>
      )}
    </div>
  );
};
