import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Trash2, Image as ImageIcon, Star, Video, Upload, Link as LinkIcon, FileText } from 'lucide-react';
import { Button, Input } from './ui/BaseComponents';
import { useAppContext } from '../contexts/AppContext';
import { Property } from '../types';

interface AddPropertyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddPropertyModal: React.FC<AddPropertyModalProps> = ({ isOpen, onClose }) => {
  const { addProperty, t } = useAppContext();
  const [formData, setFormData] = useState({
    title: '',
    price: '',
    location: '',
    area: '',
    bedrooms: '',
    bathrooms: '',
    videoUrl: '',
    description: ''
  });
  
  const [imageInput, setImageInput] = useState('');
  const [images, setImages] = useState<string[]>([]);
  const [coverIndex, setCoverIndex] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  // Refs for hidden file inputs
  const imageFileRef = useRef<HTMLInputElement>(null);
  const videoFileRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const addImageFromUrl = () => {
    if (imageInput.trim()) {
      setImages([...images, imageInput.trim()]);
      setImageInput('');
    }
  };

  const removeImage = (index: number) => {
    const newImages = images.filter((_, i) => i !== index);
    setImages(newImages);
    if (coverIndex >= newImages.length) setCoverIndex(0);
  };

  // Convert file to Base64 string
  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    try {
      const newImages: string[] = [];
      for (let i = 0; i < files.length; i++) {
        const base64 = await fileToBase64(files[i]);
        newImages.push(base64);
      }
      setImages([...images, ...newImages]);
    } catch (error) {
      console.error("Error uploading images", error);
      alert("حدث خطأ أثناء تحميل الصور");
    } finally {
      setIsUploading(false);
      // Reset input value to allow selecting the same file again if needed
      if (imageFileRef.current) imageFileRef.current.value = '';
    }
  };

  const handleVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check file size (limit to ~10MB for localStorage safety, though still risky)
    if (file.size > 10 * 1024 * 1024) {
      alert("حجم الفيديو كبير جداً. يرجى اختيار ملف أصغر من 10 ميجابايت أو استخدام رابط يوتيوب.");
      return;
    }

    setIsUploading(true);
    try {
      const base64 = await fileToBase64(file);
      setFormData({ ...formData, videoUrl: base64 });
    } catch (error) {
      console.error("Error uploading video", error);
      alert("حدث خطأ أثناء تحميل الفيديو");
    } finally {
      setIsUploading(false);
      if (videoFileRef.current) videoFileRef.current.value = '';
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (images.length === 0) {
      alert('الرجاء إضافة صورة واحدة على الأقل');
      return;
    }

    // Sort images so cover image is first
    const sortedImages = [...images];
    if (coverIndex > 0) {
      const cover = sortedImages.splice(coverIndex, 1)[0];
      sortedImages.unshift(cover);
    }

    const newProperty: Property = {
      id: Date.now().toString(),
      title: formData.title,
      price: Number(formData.price),
      location: formData.location,
      area: Number(formData.area),
      bedrooms: Number(formData.bedrooms),
      bathrooms: Number(formData.bathrooms),
      videoUrl: formData.videoUrl,
      description: formData.description,
      images: sortedImages,
      coverImage: sortedImages[0]
    };

    try {
      addProperty(newProperty);
      onClose();
      // Reset form
      setFormData({ title: '', price: '', location: '', area: '', bedrooms: '', bathrooms: '', videoUrl: '', description: '' });
      setImages([]);
      setCoverIndex(0);
    } catch (error) {
      console.error(error);
      alert("حدث خطأ أثناء الحفظ. قد يكون حجم الصور كبيراً جداً للتخزين المحلي.");
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center px-4 overflow-y-auto py-10">
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="relative w-full max-w-2xl bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden flex flex-col max-h-[90vh]"
          >
            <div className="p-6 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white">{t('addProp.title')}</h2>
              <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200">
                <X size={24} />
              </button>
            </div>

            <div className="p-6 overflow-y-auto">
              <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Basic Info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('addProp.name')}</label>
                    <Input name="title" value={formData.title} onChange={handleInputChange} required placeholder="" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('addProp.price')}</label>
                    <Input name="price" type="number" value={formData.price} onChange={handleInputChange} required placeholder="4500000" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('addProp.location')}</label>
                    <Input name="location" value={formData.location} onChange={handleInputChange} required placeholder="" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('addProp.area')}</label>
                    <Input name="area" type="number" value={formData.area} onChange={handleInputChange} required placeholder="450" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('addProp.rooms')}</label>
                      <Input name="bedrooms" type="number" value={formData.bedrooms} onChange={handleInputChange} required placeholder="5" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{t('addProp.baths')}</label>
                      <Input name="bathrooms" type="number" value={formData.bathrooms} onChange={handleInputChange} required placeholder="6" />
                    </div>
                  </div>

                  {/* Description Field */}
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-2">
                       <FileText size={16} /> {t('addProp.description')}
                    </label>
                    <textarea 
                        name="description" 
                        value={formData.description} 
                        onChange={handleInputChange} 
                        className="flex w-full rounded-xl border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800 px-3 py-2 text-sm text-gray-900 dark:text-gray-100 ring-offset-white dark:ring-offset-gray-900 placeholder:text-gray-500 dark:placeholder:text-gray-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                        rows={4} 
                        maxLength={9999}
                        placeholder={t('addProp.description')}
                    />
                    <div className="flex justify-end mt-1">
                        <span className="text-xs text-gray-400">{formData.description.length}/9999</span>
                    </div>
                  </div>
                </div>

                {/* Video URL or Upload */}
                <div>
                   <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1 flex items-center gap-2">
                     <Video size={16} /> {t('addProp.video')}
                   </label>
                   <div className="flex gap-2">
                      <Input 
                        name="videoUrl" 
                        value={formData.videoUrl} 
                        onChange={handleInputChange} 
                        placeholder={formData.videoUrl.startsWith('data:video') ? 'تم رفع الفيديو بنجاح' : "https://youtube.com/..."}
                        className="flex-1"
                        disabled={formData.videoUrl.startsWith('data:video')}
                      />
                      <input 
                        type="file" 
                        ref={videoFileRef} 
                        onChange={handleVideoUpload} 
                        accept="video/*" 
                        className="hidden" 
                      />
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={() => videoFileRef.current?.click()}
                        className="whitespace-nowrap flex items-center gap-2"
                        disabled={isUploading}
                      >
                        <Upload size={16} /> {isUploading ? '...' : 'رفع فيديو'}
                      </Button>
                      {formData.videoUrl.startsWith('data:video') && (
                        <Button 
                          type="button" 
                          variant="ghost" 
                          className="text-red-500"
                          onClick={() => setFormData({...formData, videoUrl: ''})}
                        >
                          <Trash2 size={16} />
                        </Button>
                      )}
                   </div>
                   <p className="text-xs text-gray-400 mt-1">يمكنك وضع رابط يوتيوب أو رفع فيديو من جهازك (بحد أقصى 10 ميجابايت)</p>
                </div>

                {/* Image Management */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 flex items-center gap-2">
                    <ImageIcon size={16} /> {t('addProp.images')}
                  </label>
                  
                  <div className="flex flex-col gap-3 mb-4">
                    {/* URL Input */}
                    <div className="flex gap-2">
                      <Input 
                        value={imageInput} 
                        onChange={(e) => setImageInput(e.target.value)} 
                        placeholder="https://example.com/image.jpg"
                        className="flex-1"
                      />
                      <button type="button" onClick={addImageFromUrl} className="bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 px-4 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-600">
                        <LinkIcon size={20} />
                      </button>
                    </div>

                    {/* File Upload Button */}
                    <input 
                      type="file" 
                      ref={imageFileRef} 
                      onChange={handleImageUpload} 
                      accept="image/*" 
                      multiple 
                      className="hidden" 
                    />
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => imageFileRef.current?.click()}
                      className="w-full border-dashed border-2 py-8 flex flex-col items-center gap-2 text-gray-500 hover:text-primary-600 hover:bg-primary-50 dark:hover:bg-gray-700"
                      disabled={isUploading}
                    >
                      <Upload size={24} />
                      <span>{isUploading ? 'جاري التحميل...' : 'اضغط هنا لرفع الصور من جهازك'}</span>
                    </Button>
                  </div>
                  
                  {/* Image List / Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mt-4">
                    {images.map((img, idx) => (
                      <div key={idx} className={`relative group rounded-xl overflow-hidden aspect-square border-2 ${coverIndex === idx ? 'border-primary-500' : 'border-gray-200 dark:border-gray-600'}`}>
                        <img src={img} alt="" className="w-full h-full object-cover" />
                        
                        {/* Actions Overlay */}
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2">
                          <button 
                            type="button" 
                            onClick={() => setCoverIndex(idx)}
                            className={`px-2 py-1 text-xs rounded-full flex items-center gap-1 ${coverIndex === idx ? 'bg-yellow-400 text-black' : 'bg-white/20 text-white hover:bg-white/40'}`}
                          >
                            <Star size={12} fill={coverIndex === idx ? "black" : "none"} />
                            {coverIndex === idx ? t('addProp.cover') : t('addProp.setCover')}
                          </button>
                          <button 
                            type="button" 
                            onClick={() => removeImage(idx)}
                            className="bg-red-500 text-white p-1.5 rounded-full hover:bg-red-600"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                        
                        {/* Cover Badge */}
                        {coverIndex === idx && (
                          <div className="absolute top-2 right-2 bg-yellow-400 text-black text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm z-10">
                            {t('addProp.cover')}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  {images.length === 0 && (
                    <div className="text-center py-4 text-gray-400 text-sm">
                      لم يتم إضافة صور بعد
                    </div>
                  )}
                </div>

                <div className="flex gap-3 pt-4 border-t border-gray-100 dark:border-gray-700">
                  <Button type="submit" className="flex-1" disabled={isUploading}>{t('addProp.save')}</Button>
                  <Button type="button" variant="outline" onClick={onClose}>{t('addProp.cancel')}</Button>
                </div>
              </form>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
